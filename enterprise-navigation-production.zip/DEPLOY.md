﻿# Enterprise Navigation Tool 閮ㄧ讲鎸囧崡

## 绯荤粺瑕佹眰
- Node.js 18+
- MySQL 8.0+
- npm 鎴?yarn

## 閮ㄧ讲姝ラ

### 1. 鏁版嵁搴撳垵濮嬪寲
`ash
mysql -u root -p < database/full_schema.sql
`

### 2. 閰嶇疆鐜鍙橀噺
`ash
cp .env.production .env
# 缂栬緫 .env 鏂囦欢锛岄厤缃暟鎹簱杩炴帴绛変俊鎭?
`

### 3. 瀹夎鍚庣渚濊禆骞舵瀯寤?
`ash
npm install --production
npm run build
`

### 4. 瀹夎鍓嶇渚濊禆骞舵瀯寤?
`ash
cd frontend
npm install
npm run build
cd ..
`

### 5. 鍚姩鏈嶅姟
`ash
npm start
`

## Docker 閮ㄧ讲 (鍙€?
`ash
docker-compose -f docker-compose.dev.yml up -d
`

## 榛樿绠＄悊鍛樿处鎴?
- 鐢ㄦ埛鍚? admin
- 閭: admin@company.com
- 瀵嗙爜: admin123 (璇风珛鍗充慨鏀?)
